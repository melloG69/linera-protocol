import React, { useState, useEffect } from 'react';
import { Connection, PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Wallet, Search, ArrowUpRight, ArrowDownRight, RefreshCcw, Activity } from 'lucide-react';

const SOLANA_RPC_URL = 'https://api.mainnet-beta.solana.com';

function App() {
  const [address, setAddress] = useState('');
  const [balance, setBalance] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [transactions, setTransactions] = useState<any[]>([]);

  // Mock data for the chart (in production, this would come from historical data)
  const mockChartData = [
    { date: '2024-01', volume: 45 },
    { date: '2024-02', volume: 82 },
    { date: '2024-03', volume: 63 },
    { date: '2024-04', volume: 91 },
    { date: '2024-05', volume: 52 },
    { date: '2024-06', volume: 73 },
  ];

  const fetchWalletData = async () => {
    if (!address) return;
    
    setIsLoading(true);
    setError('');
    
    try {
      const connection = new Connection(SOLANA_RPC_URL);
      const pubKey = new PublicKey(address);
      
      const balanceResult = await connection.getBalance(pubKey);
      setBalance(balanceResult / LAMPORTS_PER_SOL);
      
      // In production, you'd fetch real transaction history here
      setTransactions([
        { type: 'receive', amount: 2.5, from: 'Wallet1...xyz' },
        { type: 'send', amount: 1.2, to: 'Wallet2...abc' },
        { type: 'receive', amount: 0.8, from: 'Wallet3...def' },
      ]);
    } catch (err) {
      setError('Invalid wallet address or network error');
      setBalance(null);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <Wallet className="w-8 h-8 text-blue-400" />
          <h1 className="text-3xl font-bold">Solana Wallet Analyzer</h1>
        </div>

        <div className="bg-gray-800 rounded-xl p-6 mb-8">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Enter Solana wallet address"
                  className="w-full bg-gray-700 rounded-lg px-4 py-3 pr-12 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
              </div>
            </div>
            <button
              onClick={fetchWalletData}
              disabled={isLoading}
              className="bg-blue-500 hover:bg-blue-600 px-6 py-3 rounded-lg flex items-center gap-2 transition-colors"
            >
              {isLoading ? <RefreshCcw className="animate-spin" /> : 'Analyze'}
            </button>
          </div>
          {error && <p className="text-red-400 mt-2">{error}</p>}
        </div>

        {balance !== null && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div className="bg-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Activity className="text-blue-400" />
                Current Balance
              </h2>
              <p className="text-4xl font-bold">{balance.toFixed(4)} SOL</p>
            </div>
            
            <div className="bg-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold mb-4">Volume History</h2>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={mockChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="date" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1F2937', border: 'none' }}
                      labelStyle={{ color: '#9CA3AF' }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="volume" 
                      stroke="#3B82F6" 
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {transactions.length > 0 && (
          <div className="bg-gray-800 rounded-xl p-6">
            <h2 className="text-xl font-semibold mb-4">Recent Transactions</h2>
            <div className="space-y-4">
              {transactions.map((tx, index) => (
                <div key={index} className="flex items-center justify-between bg-gray-700 p-4 rounded-lg">
                  {tx.type === 'receive' ? (
                    <div className="flex items-center gap-3">
                      <ArrowDownRight className="text-green-400" />
                      <div>
                        <p className="font-medium">Received {tx.amount} SOL</p>
                        <p className="text-sm text-gray-400">From: {tx.from}</p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3">
                      <ArrowUpRight className="text-red-400" />
                      <div>
                        <p className="font-medium">Sent {tx.amount} SOL</p>
                        <p className="text-sm text-gray-400">To: {tx.to}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;